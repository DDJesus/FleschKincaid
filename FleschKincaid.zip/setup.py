from setuptools import setup

setup(
	name='FleschKincaid',
	version='0.1',
	scripts=['FleschKincaid.py']
)